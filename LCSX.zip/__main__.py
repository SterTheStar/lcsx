import sys
import os

# Add the lcsx directory to path
sys.path.insert(0, os.path.dirname(__file__))

from lcsx import main

if __name__ == "__main__":
    main()
